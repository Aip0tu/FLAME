from typing import List

import torch
from tqdm import tqdm

from FLAME_plugin.dataprocess.data import MoleculeDataLoader, MoleculeDataset, StandardScaler
from FLAME_plugin.models import MoleculeModel


def predict(model: MoleculeModel,
            data_loader: MoleculeDataLoader,
            disable_progress_bar: bool = False,
            scaler: StandardScaler = None) -> List[List[float]]:
    """
    Makes predictions on a dataset using an ensemble of models.

    :param model: A :class:`~flam.models.model.MoleculeModel`.
    :param data_loader: A :class:`~flam.data.data.MoleculeDataLoader`.
    :param disable_progress_bar: Whether to disable the progress bar.
    :param scaler: A :class:`~flam.features.scaler.StandardScaler` object fit on the training targets.
    :return: A list of lists of predictions. The outer list is molecules while the inner list is tasks.
    """
    model.eval()

    preds = []

    for batch in data_loader:
        # Prepare batch
        batch: MoleculeDataset
        mol_batch, features_batch, mol_adj_batch, mol_dist_batch, mol_clb_batch = \
            batch.batch_graph(), batch.features(), batch.adj_features(
            ), batch.dist_features(), batch.clb_features()

        # Make predictions
        with torch.no_grad():
            batch_preds = model(mol_batch, features_batch,
                                mol_adj_batch, mol_dist_batch, mol_clb_batch)

        batch_preds = batch_preds.data.cpu().numpy()

        # Inverse scale if regression
        if scaler is not None:
            batch_preds = scaler.inverse_transform(batch_preds)

        # Collect vectors
        batch_preds = batch_preds.tolist()
        preds.extend(batch_preds)

    return preds
